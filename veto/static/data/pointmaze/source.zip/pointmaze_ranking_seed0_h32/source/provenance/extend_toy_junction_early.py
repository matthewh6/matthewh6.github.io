"""Prespecified early data prefixes at the existing H32 junction; no scene search."""
from toy_verifier_pointmaze import *


def main():
    torch.set_num_threads(1)
    dest=ROOT/'logs/toy_verifier_pointmaze/junction32_view'
    protocol=dict(new_prefixes=[16,32,64,128],displayed_prefixes=[0,32,64,256,4096],
                  seed=0,horizon=32,updates_per_fit=500,
                  selection='Prespecified early prefixes; same saved scene and all candidate actions. No new scene, candidate, seed or optimizer search.',
                  caveat='Independent fits on nested data prefixes, not sequential checkpoints of one training run. Zero is an untrained initialization with zero updates. A prefix shorter than H has no full-H observed returns; direct training uses available shorter suffixes.',
                  display_revision='User requested 0/32/64/256/4096. Added a fresh 32-transition fit with the unchanged protocol, retaining all previous predictions and early-prefix results.')
    (dest/'early_prefix_protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    ev=np.load(dest/'evaluation.npz');data=dict(np.load(ROOT/'logs/toy_verifier_pointmaze/v1/data_s0.npz'))
    truth=ev['returns'];best=np.sort(truth)[-4:].mean();ranks=np.argsort(np.argsort(-truth))+1;records=[]
    for n in [0]+protocol['new_prefixes']:
        path=dest/f'predictions_n{n}.npz'
        if path.exists():
            pred=dict(np.load(path))
        else:
            model=Scorers(32,0)
            if n>0:model.fit(data,n,500,33000)
            pred={m:model.score(m,np.repeat(ev['x'][None],16,0),np.repeat(ev['g'][None],16,0),ev['a']) for m in METHODS}
            np.savez_compressed(path,**pred)
        for m,p in pred.items():
            chosen=np.argsort(p)[-4:]
            r=dict(transitions=n,updates=500 if n>0 else 0,method=m,regret=float(best-truth[chosen].mean()),ranks=sorted(ranks[chosen].tolist()))
            records.append(r);print(json.dumps(r),flush=True)
    (dest/'early_prefix_results.json').write_text(json.dumps(dict(protocol=protocol,results=records),indent=2)+'\n')


if __name__=='__main__':main()
