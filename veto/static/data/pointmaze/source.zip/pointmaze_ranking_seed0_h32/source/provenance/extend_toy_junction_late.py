"""Find the first tested shared-data prefix with oracle top-four selection for all methods."""
from toy_verifier_pointmaze import *


def main():
    torch.set_num_threads(1)
    dest=ROOT/'logs/toy_verifier_pointmaze/junction32_view'
    protocol=dict(prefixes=[4096,8192,16384,32768],seed=0,data_rng_seed=17000,horizon=32,updates=500,
                  criterion='First tested prefix where all three methods select exactly the simulator-oracle top four on the existing fixed illustrative scene.',
                  controls='Same seed, initialization, 500-update budget, environment, proposal process and fixed candidate set. Nested original training-data stream.',
                  limitation='Endpoint explicitly selected using this illustrative evaluation; not an independent convergence guarantee or full-16-ranking claim.')
    (dest/'late_prefix_protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    data_path=dest/'extended_data_s0_rng17000.npz'
    if data_path.exists():data=dict(np.load(data_path))
    else:
        print('Collecting 32,768 transitions from original seed-0 data stream',flush=True)
        maze=Maze();data=collect(maze,17000,32768);maze.wrapper.close()
        np.savez_compressed(data_path,**data)
    original=np.load(ROOT/'logs/toy_verifier_pointmaze/v1/data_s0.npz')
    for k in original.files:np.testing.assert_array_equal(data[k][:2304],original[k])
    print('Original 2,304-transition prefix matches bitwise',flush=True)
    ev=np.load(dest/'evaluation.npz');truth=ev['returns'];oracle=np.sort(truth)[-4:].mean()
    ranks=np.argsort(np.argsort(-truth))+1;records=[];chosen=None
    for n in protocol['prefixes']:
        model=Scorers(32,0);model.fit(data,n,500,33000)
        pred={m:model.score(m,np.repeat(ev['x'][None],16,0),np.repeat(ev['g'][None],16,0),ev['a']) for m in METHODS}
        np.savez_compressed(dest/f'predictions_n{n}.npz',**pred)
        rr=[]
        for method,p in pred.items():
            selected=np.argsort(p)[-4:]
            row=dict(transitions=n,method=method,regret=float(oracle-truth[selected].mean()),
                     ranks=sorted(ranks[selected].tolist()),full_ranking_correct=bool(np.array_equal(np.argsort(p),np.argsort(truth))))
            rr.append(row);records.append(row);print(json.dumps(row),flush=True)
        if all(r['ranks']==[1,2,3,4] for r in rr):chosen=n
        audit=dict(protocol=protocol,original_prefix_bitwise_match=True,results=records,selected_endpoint=chosen)
        (dest/'late_prefix_results.json').write_text(json.dumps(audit,indent=2)+'\n')
        if chosen is not None:break


if __name__=='__main__':main()
