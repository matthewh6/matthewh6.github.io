"""Fit requested exact data prefixes on the existing H32 illustrative scene."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['OMP_NUM_THREADS']='1'
os.environ['OPENBLAS_NUM_THREADS']='1'
import argparse, ast, copy, json
from pathlib import Path
import numpy as np
import torch
from torch import nn
ROOT=Path(__file__).resolve().parents[1]
GAMMA=.995
METHODS=['WM-SL','Direct-SL','Direct-TD']
# Original scorer definitions verbatim; no unused simulator imports.
source=ROOT/'scripts/toy_verifier_pointmaze.py'
tree=ast.parse(source.read_text())
defs=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ('examples','mlp','direct_input','Scorers')]
assert len(defs)==4
exec(compile(ast.Module(body=defs,type_ignores=[]),str(source),'exec'),globals())

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prefixes',type=int,nargs='+',default=[1024,2048]);args=parser.parse_args()
    torch.set_num_threads(1)
    dest=ROOT/'logs/toy_verifier_pointmaze/junction32_view'
    data=dict(np.load(dest/'extended_data_s0_rng17000.npz'))
    original=np.load(ROOT/'logs/toy_verifier_pointmaze/v1/data_s0.npz')
    for k in original.files:np.testing.assert_array_equal(data[k][:len(original[k])],original[k])
    ev=np.load(dest/'evaluation.npz');xx=np.repeat(ev['x'][None],16,0);gg=np.repeat(ev['g'][None],16,0)
    # Reproduce an existing checkpoint before producing additional predictions.
    check=Scorers(32,0);check.fit(data,64,500,33000)
    reference=np.load(dest/'predictions_n64.npz')
    for m in METHODS:np.testing.assert_array_equal(check.score(m,xx,gg,ev['a']),reference[m])
    records=[]
    for n in args.prefixes:
        assert 0<n<=len(data['x'])
        target=dest/f'predictions_n{n}.npz'
        if target.exists():
            print(f'Already exists: {target}',flush=True);continue
        model=Scorers(32,0);model.fit(data,n,500,33000)
        pred={m:model.score(m,xx,gg,ev['a']) for m in METHODS}
        np.savez_compressed(target,**pred)
        record=dict(transitions=n,seed=0,horizon=32,updates=500,selected={m:np.argsort(p)[-4:].tolist() for m,p in pred.items()})
        records.append(record);print(json.dumps(record),flush=True)
    audit=dict(original_prefix_bitwise_match=True,existing_n64_predictions_bitwise_match=True,
               protocol='Fresh initialization for each exact nested data prefix, original seed0 and minibatch RNG33000, 500 updates; unchanged saved H32 scene and 16 candidates; no scene or optimizer search.',results=records)
    (dest/('exact_prefixes_'+'_'.join(map(str,args.prefixes))+'.json')).write_text(json.dumps(audit,indent=2)+'\n')

if __name__=='__main__':main()
