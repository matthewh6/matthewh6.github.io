"""Extend the fixed illustrative junction to H32 without selecting a new scene."""
from toy_verifier_pointmaze import *


def main():
    torch.set_num_threads(1)
    source = ROOT/'logs/toy_verifier_pointmaze/junction_view'
    dest = ROOT/'logs/toy_verifier_pointmaze/junction32_view'
    dest.mkdir(exist_ok=True)
    old = np.load(source/'evaluation.npz')
    rng = np.random.default_rng(52000)
    angle = rng.uniform(-np.pi, np.pi, (16, 1))
    direction = np.concatenate([np.cos(angle), np.sin(angle)], axis=1)
    prefix = np.clip(direction[:, None] + rng.normal(0, .25, (16, 16, 2)), -1, 1).astype('f')
    np.testing.assert_array_equal(prefix, old['a'])
    tail = np.clip(direction[:, None] + rng.normal(0, .25, (16, 16, 2)), -1, 1).astype('f')
    actions = np.concatenate([prefix, tail], axis=1)
    maze = Maze(); paths = []; returns = []
    for chunk in actions:
        maze.reset(old['x'], old['g']); path = [old['x'].copy()]; ret = 0.
        for t, action in enumerate(chunk):
            y, reward = maze.step(action, old['g'])
            path.append(y); ret += GAMMA**t * reward
        paths.append(path); returns.append(ret)
    paths = np.asarray(paths)
    np.testing.assert_allclose(paths[:, :17], old['paths'], rtol=0, atol=1e-10)
    np.savez_compressed(dest/'evaluation.npz', x=old['x'], g=old['g'], a=actions,
                        paths=paths, returns=np.asarray(returns))
    data = dict(np.load(ROOT/'logs/toy_verifier_pointmaze/v1/data_s0.npz'))
    fits = []
    for n in [256, 512, 768, 1280, 2304]:
        model = Scorers(32, 0); model.fit(data, n, 500, 33000)
        pred = {method: model.score(method, np.repeat(old['x'][None], 16, 0),
                                   np.repeat(old['g'][None], 16, 0), actions) for method in METHODS}
        np.savez_compressed(dest/f'predictions_n{n}.npz', **pred)
        best = np.sort(returns)[-4:].mean()
        record = dict(transitions=n, updates=500, seed=0,
                      regret={method: float(best-np.asarray(returns)[np.argsort(p)[-4:]].mean())
                              for method, p in pred.items()})
        fits.append(record); print(json.dumps(record), flush=True)
    search = json.loads((source/'search_results.json').read_text())
    (dest/'search_results.json').write_text(json.dumps(search, indent=2)+'\n')
    audit = dict(horizon=32, original_horizon=16, candidates=16, seed=0, fits=fits,
                 same_initial_actions=True, prefix_replay_max_error=float(np.max(np.abs(paths[:, :17]-old['paths']))),
                 protocol='Same previously selected H16 scene and headings; append 16 fresh noise steps. No new scene or candidate search. Refit all H32 scorers on original prefixes for 500 updates; learned reward head. Recompute full H32 simulated returns.',
                 limitation='Selected single-seed illustration, not new aggregate evidence; H32 changes the scoring horizon and direct input dimension. Original aggregate curves remain H1/4/8/16.')
    (dest/'horizon_extension.json').write_text(json.dumps(audit, indent=2)+'\n')
    maze.wrapper.close()


if __name__ == '__main__': main()
