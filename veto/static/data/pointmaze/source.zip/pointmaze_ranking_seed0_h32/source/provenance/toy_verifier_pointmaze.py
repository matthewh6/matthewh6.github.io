"""CPU-only matched-horizon verifier pilot using TMRL's pinned OGBench PointMaze."""
import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''
os.environ['MUJOCO_GL'] = 'osmesa'
os.environ['PYOPENGL_PLATFORM'] = 'osmesa'
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'third_party/ogbench'))
import argparse
import copy
import hashlib
import json
import time
import numpy as np
import torch
from torch import nn
import ogbench
import mujoco
from scipy.stats import rankdata

GAMMA = .995
METHODS = ['WM-SL', 'Direct-SL', 'Direct-TD']


class Maze:
    def __init__(self):
        self.wrapper = ogbench.make_env_and_datasets('pointmaze-large-navigate-v0', env_only=True,
            render_mode=None, width=64, height=64, terminate_at_goal=False)
        self.wrapper.reset(seed=0)
        self.env = self.wrapper.unwrapped
        self.cells = np.argwhere(self.env.maze_map == 0)

    def free(self, xy):
        i,j = self.env.xy_to_ij(xy)
        return 0 <= i < len(self.env.maze_map) and 0 <= j < self.env.maze_map.shape[1] and self.env.maze_map[i,j] == 0

    def pair(self, rng):
        for _ in range(10000):
            cell = self.cells[rng.integers(len(self.cells))]
            x = np.asarray(self.env.ij_to_xy(cell)) + rng.uniform(-1.2,1.2,2)
            angle = rng.uniform(-np.pi,np.pi)
            goal = x + rng.uniform(3,6) * np.array([np.cos(angle),np.sin(angle)])
            if self.free(goal):
                local = all(self.free(z) for z in np.linspace(x,goal,40))
                return x,goal,local
        raise RuntimeError('Could not sample valid start/goal')

    def reset(self, x, goal):
        mujoco.mj_resetData(self.env.model,self.env.data)
        self.env.set_state(np.array(x,dtype=float),np.zeros(2))
        self.env.set_goal(goal_xy=np.array(goal,dtype=float))

    def step(self, action, goal):
        self.env.step(np.asarray(action,dtype=float))
        x = self.env.get_xy().copy()
        return x, -np.linalg.norm(x-goal)/4


def proposals(rng, horizon, count=16):
    angle = rng.uniform(-np.pi,np.pi,(count,1))
    direction = np.concatenate([np.cos(angle),np.sin(angle)],axis=1)
    return np.clip(direction[:,None,:] + rng.normal(0,.25,(count,horizon,2)), -1,1).astype('f')


def collect(maze, seed, n=2304):
    rng=np.random.default_rng(seed); xs=[]; ys=[]; acts=[]; goals=[]; rewards=[]; ends=[]
    for base in range(0,n,64):
        x,g,_=maze.pair(rng);maze.reset(x,g)
        chunk=proposals(rng,64,1)[0]
        for a in chunk:
            y,r=maze.step(a,g)
            xs.append(x.copy());ys.append(y);acts.append(a);goals.append(g);rewards.append(r);ends.append(base+64)
            x=y
    return {k:np.asarray(v,dtype='f') for k,v in dict(x=xs,y=ys,a=acts,g=goals,r=rewards,end=ends).items()}


def examples(data,n,h):
    # Every target is a suffix wholly inside an observed episode and data prefix.
    rows=[]
    for i in range(n):
        for length in range(1,min(h,n-i,int(data['end'][i])-i)+1):rows.append((i,length))
    ids=np.array([i for i,l in rows]);length=np.array([l for i,l in rows]); mask=np.arange(h)[None,:]<length[:,None]
    take=np.minimum(ids[:,None]+np.arange(h)[None,:],n-1)
    actions=data['a'][take]*mask[:,:,None]
    returns=(data['r'][take]*mask*(GAMMA**np.arange(h))).sum(1)
    return tuple(torch.tensor(x,dtype=torch.float32) for x in
        (data['x'][ids],data['y'][ids],data['g'][ids],actions,length,returns,data['r'][ids]))


def mlp(inputs,outputs):
    return nn.Sequential(nn.Linear(inputs,64),nn.SiLU(),nn.Linear(64,64),nn.SiLU(),nn.Linear(64,outputs))


def direct_input(x,g,a,length,h):
    return torch.cat([x/40,(g-x)/4,a.flatten(1),length[:,None]/h],1)


class Scorers:
    def __init__(self,h,seed,raw_goal=False):
        torch.manual_seed(seed);self.h=h
        self.raw_goal=raw_goal
        self.sl=mlp(5+2*h,1);self.td=copy.deepcopy(self.sl);self.target=copy.deepcopy(self.td)
        self.dynamics=mlp(4,2);self.reward=mlp(4,1)
        self.opts=[torch.optim.Adam(m.parameters(),lr=.001) for m in (self.sl,self.td)]
        self.wopt=torch.optim.Adam(list(self.dynamics.parameters())+list(self.reward.parameters()),lr=.001)

    def goal_features(self,x,g):
        return torch.cat([x/40,g/40 if self.raw_goal else (g-x)/4],1)

    def direct_features(self,x,g,a,length):
        return torch.cat([self.goal_features(x,g),a.flatten(1),length[:,None]/self.h],1)

    @torch.no_grad()
    def score(self,method,x,g,a):
        x=torch.as_tensor(x,dtype=torch.float32);g=torch.as_tensor(g,dtype=torch.float32);a=torch.as_tensor(a,dtype=torch.float32)
        if method!='WM-SL':
            m=self.sl if method=='Direct-SL' else self.td
            return m(self.direct_features(x,g,a,torch.full((len(x),),self.h)))[:,0].numpy()
        val=torch.zeros(len(x))
        for t in range(self.h):
            x=x+.2*self.dynamics(torch.cat([x/40,a[:,t]],1))
            val+=GAMMA**t*self.reward(self.goal_features(x,g))[:,0]
        return val.numpy()

    def fit(self,data,n,updates,seed,callback=None):
        ex=examples(data,n,self.h);rng=np.random.default_rng(seed)
        tensors={k:torch.tensor(data[k][:n]) for k in ['x','y','a','g','r']}
        for step in range(updates):
            ids=rng.integers(len(ex[0]),size=128)
            x,y,g,a,length,ret,r=(z[ids] for z in ex)
            inputs=self.direct_features(x,g,a,length)
            tail=torch.cat([a[:,1:],torch.zeros_like(a[:,:1])],1)
            with torch.no_grad():
                boot=self.target(self.direct_features(y,g,tail,length-1))[:,0]
                td_target=r+GAMMA*torch.where(length>1,boot,torch.zeros_like(boot))
            for model,opt,target in zip((self.sl,self.td),self.opts,(ret,td_target)):
                loss=(model(inputs)[:,0]-target).square().mean();opt.zero_grad();loss.backward();opt.step()
            with torch.no_grad():
                for target,p in zip(self.target.parameters(),self.td.parameters()):target.lerp_(p,.01)
            ids=rng.integers(n,size=128);x,y,a,g,r=(tensors[k][ids] for k in ['x','y','a','g','r'])
            pred=self.dynamics(torch.cat([x/40,a],1));reward=self.reward(self.goal_features(y,g))[:,0]
            loss=(pred-(y-x)/.2).square().mean()+(reward-r).square().mean()
            self.wopt.zero_grad();loss.backward();self.wopt.step()
            if callback is not None:callback(step+1,self)
        if self.h==1:
            assert all(torch.equal(a,b) for a,b in zip(self.sl.parameters(),self.td.parameters())), 'H1 SL/TD equivalence failed'


def evaluation_set(maze,seed,h,count=48):
    rng=np.random.default_rng(seed);action_rng=np.random.default_rng(seed+500000)
    xs=[];gs=[];actions=[];paths=[];returns=[];local=[]
    for _ in range(count):
        x,g,l=maze.pair(rng);aa=proposals(action_rng,16)[:,:h];pp=[];rr=[]
        for a in aa:
            maze.reset(x,g);path=[x.copy()];ret=0
            for t,at in enumerate(a):
                y,r=maze.step(at,g);path.append(y);ret+=GAMMA**t*r
            pp.append(path);rr.append(ret)
        xs.append(x);gs.append(g);actions.append(aa);paths.append(pp);returns.append(rr);local.append(l)
    return {k:np.asarray(v) for k,v in dict(x=xs,g=gs,a=actions,paths=paths,returns=returns,local=local).items()}


def evaluate(model,ev):
    n,k,h,_=ev['a'].shape;result={};preds={}
    truth=ev['returns'];best=np.sort(truth,axis=1)[:,-4:].mean(1)
    for method in METHODS:
        pred=model.score(method,np.repeat(ev['x'],k,0),np.repeat(ev['g'],k,0),ev['a'].reshape(n*k,h,2)).reshape(n,k)
        selected=np.argsort(pred,axis=1)[:,-4:];actual=np.take_along_axis(truth,selected,axis=1).mean(1)
        corr=[]
        for t,p in zip(truth,pred):
            t=rankdata(t);p=rankdata(p);corr.append(float(np.corrcoef(t,p)[0,1]) if min(np.std(t),np.std(p))>1e-8 else 0)
        result[method]=dict(regret=float(np.mean(best-actual)),regret_per_step=float(np.mean(best-actual)/h),
                            spearman=float(np.mean(corr)),local_regret=float(np.mean((best-actual)[ev['local']])) if ev['local'].any() else None)
        preds[method]=pred
    return result,preds


def behavior(maze,model,seed,count=16):
    pairs_rng=np.random.default_rng(seed);pairs=[maze.pair(pairs_rng) for _ in range(count)];out={}
    for method in METHODS+['Unguided']:
        success=[];steps=[]
        for i,(x,g,local) in enumerate(pairs):
            rng=np.random.default_rng(seed+1000+i);maze.reset(x,g);ok=False
            for t in range(0,128,model.h):
                a=proposals(rng,model.h)
                if method=='Unguided': idx=int(rng.integers(16))
                else:
                    pred=model.score(method,np.repeat(x[None],16,0),np.repeat(g[None],16,0),a)
                    idx=int(rng.choice(np.argsort(pred)[-4:]))
                # Commit the whole chunk; success is measured at replanning boundaries.
                for at in a[idx]:x,_=maze.step(at,g)
                if np.linalg.norm(x-g)<=1.5:ok=True;break
            success.append(ok);steps.append(t+model.h if ok else 128)
        out[method]=dict(success=float(np.mean(success)),capped_steps=float(np.mean(steps)),episodes=count)
    return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--seeds',nargs='+',type=int,default=[0,1,2]);ap.add_argument('--horizons',nargs='+',type=int,default=[1,4,8,16]);ap.add_argument('--updates',type=int,default=500);ap.add_argument('--output',default='logs/toy_verifier_pointmaze/v1');args=ap.parse_args()
    torch.set_num_threads(1);dest=ROOT/args.output;dest.mkdir(parents=True,exist_ok=True)
    manifest=dict(seeds=args.seeds,horizons=args.horizons,updates=args.updates,prefixes=[256,512,768,1280,2304],gamma=GAMMA,device='cpu',environment='TMRL-pinned OGBench PointMaze large, unchanged dynamics',reward='dense added label: -distance(next_xy, goal)/4; native sparse reward not used for fitting',td_target='r + gamma*C_target(next_state, remaining_committed_actions); C_0=0',td_polyak=.01,matched_direct_initialization=True,proposal='frozen uniform heading plus iid action noise;16 candidates;uniform top4 execution',training='Fresh fit on each shared data prefix; equal500 optimizer steps per model by default;no extra simulator labels for training',limitations='Small CPU pilot. State inputs and synthetic dense labels. WM parameters/transition sampling differ from direct models. Full-horizon Q and auxiliary-dynamics control not yet included. No policy learning is performed.',source={'tmrl':'a881748b612460cba8194aa7da10bc8bac51ae09','ogbench':'f9296121bd238427c83814f497fac4d3234b8829'})
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    maze=Maze();np.save(dest/'maze_map.npy',maze.env.maze_map)
    for seed in args.seeds:
        data=collect(maze,17000+seed);np.savez_compressed(dest/f'data_s{seed}.npz',**data)
        for h in args.horizons:
            ev=evaluation_set(maze,29000+seed,h);np.savez_compressed(dest/f'evaluation_s{seed}_h{h}.npz',**ev)
            for n in manifest['prefixes']:
                file=dest/f'result_s{seed}_h{h}_n{n}.json'
                if file.exists():continue
                start=time.time();model=Scorers(h,seed);model.fit(data,n,args.updates,33000+seed)
                scores,pred=evaluate(model,ev)
                result=dict(seed=seed,horizon=h,transitions=n,extra_transitions=n-256,scores=scores,seconds=time.time()-start,h1_exact_match=(h==1))
                if h==8 and n in (256,2304):result['behavior']=behavior(maze,model,41000+seed)
                np.savez_compressed(dest/f'predictions_s{seed}_h{h}_n{n}.npz',**pred)
                file.write_text(json.dumps(result,indent=2)+'\n')
                print(json.dumps(result),flush=True)
    maze.wrapper.close();(dest/'DONE').write_text(str(time.time()))


if __name__=='__main__':main()
