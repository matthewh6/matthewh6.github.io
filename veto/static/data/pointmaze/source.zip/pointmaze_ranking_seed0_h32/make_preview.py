#!/usr/bin/env python3
"""Build an animated preview and standalone interactive view from measured rankings."""
from __future__ import annotations

import base64
import io
import json
import subprocess
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
from PIL import Image

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE / "ranking.json").read_text())
COLORS = {"VETO": "#0E7E33", "H-return": "#815F43", "Q-TD": "#8995A4"}
METHODS = list(COLORS)
BUDGETS = DATA["budgets"]
WALLS = DATA["maze"]["wallRectangles"]
BOUNDS = DATA["maze"]["coordinateBounds"]
VIEW = DATA["maze"]["recommendedViewBounds"]
START = DATA["evaluation"]["start"]
GOAL = DATA["evaluation"]["goal"]
PATHS = [c["path"] for c in DATA["candidates"]]


def selected(budget_index: int, method: str) -> set[str]:
    return set(BUDGETS[budget_index]["methods"][method]["selectedTopFour"])


def draw_frame(old_i: int, new_i: int, mix: float) -> Image.Image:
    old_n = BUDGETS[old_i]["trainingExampleBudget"]
    new_n = BUDGETS[new_i]["trainingExampleBudget"]
    fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.9), dpi=95)
    fig.patch.set_facecolor("#fafbfc")
    if old_i == new_i:
        fig.suptitle(f"Training examples: {new_n:,}", fontsize=17, y=0.99, color="#20262b")
    else:
        fig.suptitle(f"Training examples: {old_n:,}  →  {new_n:,}", fontsize=17, y=0.99, color="#20262b")
    for ax, method in zip(axes, METHODS):
        ax.set_facecolor("#e9edef")
        for wall in WALLS:
            ax.add_patch(Rectangle((wall["x"], wall["y"]), wall["width"], wall["height"],
                                   facecolor="#7b8790", edgecolor="none", zorder=0))
        # The same 16 recorded paths are present in every frame; only emphasis changes.
        for i, path in enumerate(PATHS):
            xs = [p[0] for p in path]
            ys = [p[1] for p in path]
            ax.plot(xs, ys, color="#788894", linewidth=0.9, alpha=0.30,
                    linestyle=(0, (2.2, 2.4)), zorder=1)
            cid = f"candidate-{i:02d}"
            was = cid in selected(old_i, method)
            now = cid in selected(new_i, method)
            weight = (1.0 - mix) * float(was) + mix * float(now)
            if weight > 0.001:
                ax.plot(xs, ys, color=COLORS[method], linewidth=1.1 + 1.15 * weight,
                        alpha=0.95 * weight, solid_capstyle="round", zorder=2)
        ax.add_patch(Circle(START, radius=0.9, facecolor="#f8fafb", edgecolor=COLORS[method],
                            linewidth=1.8, zorder=4))
        ax.scatter([GOAL[0]], [GOAL[1]], marker="*", s=185, color="#E3B63F",
                   edgecolors="none", zorder=5)
        ax.set_xlim(*VIEW["x"])
        ax.set_ylim(*VIEW["y"])
        ax.set_aspect("equal")
        ax.set_title(method, color=COLORS[method], fontsize=16, pad=9)
        ax.axis("off")
    fig.subplots_adjust(left=0.015, right=0.99, bottom=0.02, top=0.86, wspace=0.08)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=fig.get_facecolor(), bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)
    buf.seek(0)
    return Image.open(buf).convert("RGB")


def make_mp4() -> None:
    fps = 12
    output = HERE / "animation_preview.mp4"
    first_frame = draw_frame(0, 0, 0.0)
    width, height = first_frame.size
    command = [
        "ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
        "-s", f"{width}x{height}", "-r", str(fps), "-i", "-", "-vf", "pad=ceil(iw/2)*2:ceil(ih/2)*2",
        "-an", "-c:v", "libx264", "-preset", "slow", "-crf", "19", "-pix_fmt", "yuv420p",
        "-movflags", "+faststart", str(output),
    ]
    proc = subprocess.Popen(command, stdin=subprocess.PIPE)
    assert proc.stdin is not None
    # The timeline visits exact measured checkpoints. Between them, only the
    # path-emphasis opacity eases; no scores, ranks, IDs, or coordinates are made up.
    try:
        for i in range(len(BUDGETS)):
            image = first_frame if i == 0 else draw_frame(i, i, 0.0)
            if image.size != (width, height):
                raise RuntimeError(f"unexpected preview frame size: {image.size}")
            for _ in range(3):
                proc.stdin.write(image.tobytes())
            if i + 1 < len(BUDGETS):
                for j in range(1, 9):
                    raw = j / 8
                    eased = raw * raw * (3.0 - 2.0 * raw)
                    proc.stdin.write(draw_frame(i, i + 1, eased).tobytes())
    finally:
        proc.stdin.close()
    if proc.wait() != 0:
        raise RuntimeError("ffmpeg failed to encode animation preview")


def make_html() -> None:
    payload = json.dumps(DATA, separators=(",", ":"), ensure_ascii=False)
    bg = base64.b64encode((HERE / "junction32_background.svg").read_bytes()).decode("ascii")
    template = r'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>PointMaze candidate rankings</title>
<style>
*{box-sizing:border-box}body{margin:0;padding:22px;background:#fafbfc;color:#20262b;font:16px system-ui,sans-serif}
main{max-width:1320px;margin:auto}header{display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap}
h1{font-size:clamp(22px,3vw,34px);font-weight:550;margin:0 0 12px}#count{font-variant-numeric:tabular-nums;font-size:20px;font-weight:600}
.controls{display:flex;align-items:center;gap:10px;margin:10px 0 18px}button{border:1px solid #bac3c9;background:white;border-radius:8px;padding:8px 14px;font:inherit;cursor:pointer}
input[type=range]{flex:1;min-width:180px;accent-color:#0e7e33}.panels{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}
.panel{min-width:0;text-align:center}.panel h2{font-size:20px;font-weight:600;margin:0 0 8px}.panel svg{display:block;width:100%;height:auto;background:#e9edef;border-radius:3px}
.base{fill:none;stroke:#788894;stroke-width:.8;stroke-dasharray:3.5 4;opacity:.33}.selected{fill:none;stroke-width:1.7;stroke-linecap:round;opacity:0;transition:opacity .65s ease,stroke-width .65s ease}
@media(max-width:760px){.panels{grid-template-columns:1fr}.panel{max-width:520px;margin:auto;width:100%}}
</style><main><header><h1>PointMaze candidate rankings</h1><div id="count" aria-live="polite"></div></header>
<div class="controls"><button id="play" type="button">Play</button><button id="replay" type="button">Replay</button><input id="budget" type="range" min="0" max="13" step="1" value="0" aria-label="Training examples"><span id="ordinal"></span></div>
<section class="panels" id="panels"></section></main>
<script>
const data=__DATA__;
const methods=[['VETO','#0E7E33'],['H-return','#815F43'],['Q-TD','#8995A4']];
const bg='data:image/svg+xml;base64,__BG__';
const budgets=data.budgets, paths=data.candidates, range=document.querySelector('#budget');
range.max=budgets.length-1;
const panels=document.querySelector('#panels');
for(const [method,color] of methods){
 const p=document.createElement('article');p.className='panel';
 const h=document.createElement('h2');h.textContent=method;p.appendChild(h);
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 60 200 240');
 const im=document.createElementNS(svg.namespaceURI,'image');im.setAttribute('href',bg);im.setAttribute('width','480');im.setAttribute('height','360');svg.appendChild(im);
 const candidates=[];
 for(const c of paths){const d=c.path.map((xy,j)=>`${j?'L':'M'} ${(xy[0]+6)*10} ${(30-xy[1])*10}`).join(' ');
  const base=document.createElementNS(svg.namespaceURI,'path');base.setAttribute('d',d);base.setAttribute('class','base');svg.appendChild(base);
  const hi=document.createElementNS(svg.namespaceURI,'path');hi.setAttribute('d',d);hi.setAttribute('class','selected');hi.setAttribute('stroke',color);hi.dataset.id=c.id;svg.appendChild(hi);candidates.push(hi);
 }
 const st=data.evaluation.start,go=data.evaluation.goal;
 const circle=document.createElementNS(svg.namespaceURI,'circle');circle.setAttribute('cx',(st[0]+6)*10);circle.setAttribute('cy',(30-st[1])*10);circle.setAttribute('r','9');circle.setAttribute('fill','#f8fafb');circle.setAttribute('stroke',color);circle.setAttribute('stroke-width','2');svg.appendChild(circle);
 const star=document.createElementNS(svg.namespaceURI,'text');star.textContent='★';star.setAttribute('x',(go[0]+6)*10);star.setAttribute('y',(30-go[1])*10+8);star.setAttribute('text-anchor','middle');star.setAttribute('font-size','22');star.setAttribute('fill','#E3B63F');svg.appendChild(star);
 p.appendChild(svg);panels.appendChild(p);p._paths=candidates;p._method=method;
}
function setBudget(i){i=Math.max(0,Math.min(budgets.length-1,i));range.value=i;const b=budgets[i];document.querySelector('#count').textContent=`Training examples: ${b.trainingExampleBudget.toLocaleString()}`;document.querySelector('#ordinal').textContent=`${i+1} / ${budgets.length}`;
 for(const p of panels.children){const chosen=new Set(b.methods[p._method].selectedTopFour);for(const path of p._paths){const yes=chosen.has(path.dataset.id);path.style.opacity=yes?'0.95':'0';path.style.strokeWidth=yes?'2.3':'1.7';}}
}
let timer=null;function stop(){if(timer){clearInterval(timer);timer=null;}document.querySelector('#play').textContent='Play';}
function play(){stop();if(+range.value>=budgets.length-1)setBudget(0);document.querySelector('#play').textContent='Pause';timer=setInterval(()=>{let n=+range.value;if(n>=budgets.length-1){stop();return;}setBudget(n+1);},1050);}
document.querySelector('#play').addEventListener('click',()=>timer?stop():play());document.querySelector('#replay').addEventListener('click',()=>{stop();setBudget(0);play();});range.addEventListener('input',()=>{stop();setBudget(+range.value);});setBudget(0);
</script></html>'''
    html = template.replace("__DATA__", payload).replace("__BG__", bg)
    (HERE / "interactive_preview.html").write_text(html)


if __name__ == "__main__":
    make_mp4()
    make_html()
    print("Wrote animation_preview.mp4 and interactive_preview.html")
