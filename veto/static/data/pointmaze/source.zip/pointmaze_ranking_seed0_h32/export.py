#!/usr/bin/env python3
"""Rebuild browser-ready PointMaze ranking data from the bundled audited NPZs."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "source"
OUT = HERE / "ranking.json"
BUDGETS = [0, 16, 32, 64, 128, 256, 512, 768, 1024, 1280, 2048, 2304, 4096, 5096]
METHODS = {
    "VETO": "WM-SL",
    "H-return": "Direct-SL",
    "Q-TD": "Direct-TD",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    ev_path = SOURCE / "junction32_view" / "evaluation.npz"
    ev = np.load(ev_path)
    paths = ev["paths"]
    actions = ev["a"]
    returns = ev["returns"]
    start = ev["x"]
    goal = ev["g"]
    assert paths.shape == (16, 33, 2)
    assert actions.shape == (16, 32, 2)
    assert np.array_equal(paths[:, 0], np.broadcast_to(start, (16, 2)))
    oracle_order = sorted(range(16), key=lambda i: (-float(returns[i]), i))
    oracle_rank = {i: rank + 1 for rank, i in enumerate(oracle_order)}

    candidates = []
    for i in range(16):
        candidates.append({
            "id": f"candidate-{i:02d}",
            "index": i,
            "actions": actions[i].astype(float).tolist(),
            "path": paths[i].astype(float).tolist(),
            "oracleReturn": float(returns[i]),
            "oracleRank": oracle_rank[i],
        })

    budget_records = []
    for n in BUDGETS:
        pred_path = SOURCE / "junction32_view" / f"predictions_n{n}.npz"
        pred = np.load(pred_path)
        methods = {}
        for display_name, legacy_name in METHODS.items():
            scores = np.asarray(pred[legacy_name], dtype=np.float64)
            # Stable, explicit tie handling makes full order reproducible.
            order = sorted(range(16), key=lambda i: (-float(scores[i]), i))
            methods[display_name] = {
                "legacyMethod": legacy_name,
                "predictedScores": [
                    {"candidateId": f"candidate-{i:02d}", "score": float(scores[i])}
                    for i in range(16)
                ],
                "rankOrder": [f"candidate-{i:02d}" for i in order],
                "selectedTopFour": [f"candidate-{i:02d}" for i in order[:4]],
            }
        budget_records.append({
            "trainingExampleBudget": n,
            "fitType": "untrained initialization" if n == 0 else "independent fresh fit on nested data prefix",
            "updates": 0 if n == 0 else 500,
            "seed": 0,
            "horizon": 32,
            "predictionSource": f"source/junction32_view/predictions_n{n}.npz",
            "methods": methods,
        })

    meta_path = SOURCE / "source_metadata.json"
    metadata = json.loads(meta_path.read_text())
    maze_map = metadata["maze"]["grid"]
    cell_size = metadata["maze"]["cellSize"]
    wall_rects = []
    nrows, ncols = len(maze_map), len(maze_map[0])
    for row, line in enumerate(maze_map):
        for col, cell in enumerate(line):
            if str(cell) == "1":
                # OGBench ij_to_xy cell centers: x=4*col-4, y=4*row-4.
                cx, cy = col * cell_size - cell_size, row * cell_size - cell_size
                wall_rects.append({
                    "x": cx - cell_size / 2,
                    "y": cy - cell_size / 2,
                    "width": cell_size,
                    "height": cell_size,
                    "row": row,
                    "column": col,
                })

    out = {
        "schemaVersion": 1,
        "title": "PointMaze junction32 candidate rankings",
        "evaluation": {
            "seed": 0,
            "horizon": 32,
            "candidateCount": 16,
            "start": start.astype(float).tolist(),
            "goal": goal.astype(float).tolist(),
            "discount": 0.995,
            "rewardDefinition": "-distance(next position, goal) / 4",
            "oracleReturnsAvailable": True,
            "oracleTopFour": [f"candidate-{i:02d}" for i in oracle_order[:4]],
            "pathSource": "recorded MuJoCo replay; raw unsmoothed paths",
        },
        "maze": {
            "environment": "pointmaze-large-navigate-v0 (TMRL OGBench fork)",
            "coordinateConvention": "world XY, y increases upward",
            "coordinateBounds": {"x": [-6.0, 42.0], "y": [-6.0, 30.0]},
            "recommendedViewBounds": {"x": [-6.0, 14.0], "y": [0.0, 24.0]},
            "cellSize": cell_size,
            "grid": maze_map,
            "wallRectangles": wall_rects,
            "backgroundAsset": "junction32_background.svg",
        },
        "methodDefinitions": {
            "VETO": {
                "legacyMethod": "WM-SL",
                "description": "World-model rollout score using learned dynamics and reward; canonical website label for this saved verifier series.",
            },
            "H-return": {
                "legacyMethod": "Direct-SL",
                "description": "Direct supervised finite-horizon return predictor.",
            },
            "Q-TD": {
                "legacyMethod": "Direct-TD",
                "description": "Direct TD return predictor.",
            },
        },
        "budgets": budget_records,
        "candidates": candidates,
        "sourceMetadata": metadata,
    }
    OUT.write_text(json.dumps(out, indent=2, allow_nan=False) + "\n")

    # Emit an audit of the inputs used for this exact output.
    files = [ev_path, meta_path]
    files += [SOURCE / "junction32_view" / f"predictions_n{n}.npz" for n in BUDGETS]
    audit = {
        "rankingJsonSha256": sha256(OUT),
        "inputSha256": {str(p.relative_to(HERE)): sha256(p) for p in files},
        "checks": {
            "candidateCount": len(candidates),
            "pathShape": list(paths.shape),
            "allBudgetsPresent": len(budget_records) == len(BUDGETS),
            "allMethodsHave16ScoresAndRanks": all(
                len(m["predictedScores"]) == len(m["rankOrder"]) == 16
                for b in budget_records for m in b["methods"].values()
            ),
            "oracleReturnsDistinct": len(set(float(x) for x in returns)) == 16,
        },
    }
    (HERE / "audit.json").write_text(json.dumps(audit, indent=2) + "\n")
    if not all(audit["checks"].values()):
        raise SystemExit(f"audit failed: {audit['checks']}")
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
